# Opening book provenance

`opening_book.json` contains 4,694 standard-chess opening positions through ply 16. The position
set comes from the CC0-licensed `lichess-org/chess-openings` dataset. Each move was labelled
offline by Stockfish 18 at 50,000 nodes on one thread.

The submitted agent performs only a Polyglot hash lookup and a legality check. Stockfish, its
code, and its network are not included or invoked at runtime. The AI Chessathon rules explicitly
permit opening books and permit using existing engines to label training data.

Source: https://github.com/lichess-org/chess-openings
