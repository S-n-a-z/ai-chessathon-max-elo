import random
import unittest

import chess

import fast_engine


class FastMoveGeneratorTests(unittest.TestCase):
    def assert_generator_matches(self, board: chess.Board) -> None:
        expected = {move.uci() for move in board.legal_moves}
        actual = fast_engine.legal_moves_for_test(board.fen())
        self.assertEqual(actual, expected, board.fen())

    def test_special_positions(self) -> None:
        positions = (
            chess.STARTING_FEN,
            "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1",
            "r3k2r/8/8/8/8/8/8/R3K2R b KQkq - 0 1",
            "4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1",
            "4k3/P6P/8/8/8/8/p6p/4K3 w - - 0 1",
            "4r1k1/8/8/8/8/8/8/4K3 w - - 0 1",
        )
        for fen in positions:
            with self.subTest(fen=fen):
                self.assert_generator_matches(chess.Board(fen))

    def test_random_game_positions(self) -> None:
        rng = random.Random(20260904)
        board = chess.Board()
        checked = 0
        while checked < 500:
            self.assert_generator_matches(board)
            checked += 1
            moves = list(board.legal_moves)
            if not moves or board.is_game_over() or len(board.move_stack) > 180:
                board.reset()
            else:
                board.push(rng.choice(moves))

    def test_perft_reference_positions(self) -> None:
        references = (
            (chess.STARTING_FEN, 3, 8_902),
            (
                "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
                2,
                2_039,
            ),
        )
        for fen, depth, expected in references:
            with self.subTest(fen=fen, depth=depth):
                self.assertEqual(fast_engine.perft_for_test(fen, depth), expected)


if __name__ == "__main__":
    unittest.main()
